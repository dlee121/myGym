<?php
	session_start();
	$link = mysql_connect('engr-cpanel-mysql.engr.illinois.edu', 'projectmygym_acc', 'pass123');

	if (!$link) 
	{
	
	die('Could not connect: ' . mysql_error());
	
	}

	mysql_select_db('projectmygym_users');

	$email =$_POST["username"];
	
	$password =$_POST["password"];
	

	$sql="SELECT Email, Pass, Height, Weight, Gender FROM Users WHERE Email = '$email' AND Pass = '$password';";


	$res=mysql_query($sql);
	$db_field = mysql_fetch_assoc($res);
	$number = mysql_num_rows($res);

	if ($number >= 1)
	{
		$_SESSION['email'] = $email;
		$_SESSION['password'] = $password;
		$_SESSION['height'] = $db_field['Height'];
		$_SESSION['weight'] = $db_field['Weight'];
		$_SESSION['gender'] = $db_field['Gender'];
	header("Location: http://projectmygym.web.engr.illinois.edu/main.php");
	}
	else
	{
	echo "<script> alert(\"Not a valid Email/Password\"); window.location=\"http://projectmygym.web.engr.illinois.edu/\"; </script>";
	}
	mysql_close($link);



?>