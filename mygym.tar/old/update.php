<?php
	session_start();
	
	$link = mysql_connect('engr-cpanel-mysql.engr.illinois.edu', 'projectmygym_acc', 'pass123');

	if (!$link) 
	{
	
	die('Could not connect: ' . mysql_error());
	
	}

	mysql_select_db('projectmygym_users');
	/*
	$email =$_POST["newusername"];
	*/
	$height =$_POST["newheight"];
	
	$weight =$_POST["newweight"];
	
	/*
	if(!empty($email))
	{ 
		$sql="UPDATE Users SET Email=$email WHERE Email='".$_SESSION['email']."'";
		$sql="UPDATE Users SET Email=$email WHERE Email='acc1@gmail.com'";
		$_SESSION['email'] = $email;
		$res=mysql_query($sql);
	}
	*/
	if(!empty($height))
	{
		$sql="UPDATE Users SET Height=$height WHERE Email='".$_SESSION['email']."'";
		$_SESSION['height'] = $height;
		$res=mysql_query($sql);	
	}
	if(!empty($weight))
	{
		$sql="UPDATE Users SET Weight=$weight WHERE Email='".$_SESSION['email']."'";
		$_SESSION['weight'] = $weight;
		$res=mysql_query($sql);	
	}
	
	/* Need to check if the email already has an account */


	$res=mysql_query($sql);
		
	mysql_close($link);



?>