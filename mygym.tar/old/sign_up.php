<?php

	$link = mysql_connect('engr-cpanel-mysql.engr.illinois.edu', 'projectmygym_acc', 'pass123');

	if (!$link) 
	{
	
	die('Could not connect: ' . mysql_error());
	
	}

	mysql_select_db('projectmygym_users');

	$email =$_POST["username"];
	
	$password =$_POST["reqpassword"];
	
	$height =12 * $_POST["feet"]+ $_POST["inch"];
	
	$weight =$_POST["weight"];
	
	$gender =$_POST["gender"];

	$location =$_POST["location"];

	$sql="INSERT INTO Users VALUES('$email','$password','$height','$weight','$gender','$location')";
	

	$res=mysql_query($sql);
	//$num = mysql_num_row($res);
	/* Need to check if the email already has an account */
	if( $res == FALSE)
	{
		echo "<p>There was an error when creating your account, please try again.</p>";
	}
	else
	{
		session_start();
		$_SESSION['email'] = $email;
		$_SESSION['password'] = $password;
		$_SESSION['height'] = $height;
		$_SESSION['weight'] = $weight;
		$_SESSION['gender'] = $gender;
                $_SESSION['location'] = $location;
		header("Location: http://projectmygym.web.engr.illinois.edu/main.php");
	}
		
	mysql_close($link);



?>