<?php session_start() ?>
<html>
	<head>
		<title>myGym</title>
		<link type='text/css', rel='stylesheet', href='stylesheet.css'>
	</head>
	
	<body>
		<div class="window">
			<h3>Profile</h3>
			</br>
			<table>
			<form action="update.php" method="post" target="_blank">
				<tr>
					<td class="label">Email:</td>
					<td><?php echo $_SESSION['email']; ?></td>
					<td></td>

				</tr>
				<tr>
					<td class="label">Height:</td>
					<td><?php echo $_SESSION['height'] ?></td>
					<td><input name="newheight" type="text" /></td>
				</tr>
				<tr>
					<td class="label">Weight:</td>
					<td><?php echo $_SESSION['weight'] ?></td>
					<td><input name="newweight" type="text" /></td>
				</tr>
				<tr>
					<td class="label">Location:</td>
					<td><?php echo $_SESSION['location'] ?></td>
				</tr>
				<tr>
				<td class="label">

					<input name="Update" type="submit" value="Update Account" /><br/>
				</td>
				</tr>
			</form>	
			</table>
			</br></br>
			<div id="delete">
				<form action="delete.php" method="post" target="_blank">
					Username:&nbsp <input name="username" type="text" /><br/>
					Password:&nbsp <input name="password" type="password" /><br/>
					<input name="Delete" type="submit" value="Delete Account" /><br/>
				</form>
			</div>
		</div>
		<div class="window">
			<h3>Workout Generator</h3>
			<form action="generate.php" method="post" target="_self">
				<div id="levelbox">
					<h4>Select Your Level:</h4>
					<input type="radio" name="level" value="1" checked />Beginner<br>
					<input type="radio" name="level" value="2" />Intermediate<br>
					<input type="radio" name="level" value="3" />Advanced<br>					
				</div>
				<div id="injurybox">
					<h4>Injuries (Check all that apply):</h4>
					<input type="checkbox" name="avoid[]" value="shoulder" />shoulder<br>
					<input type="checkbox" name="avoid[]" value="wrist" />wrist<br> 
					<input type="checkbox" name="avoid[]" value="lowerback" />lower Back<br> 
					<input type="checkbox" name="avoid[]" value="knee" />knee<br> 
					<input type="checkbox" name="avoid[]" value="ankle" />ankle<br> 
				</div>
				<input name="generate" type="submit" value="Submit" />
			</form>			
			</br>
		</div>
	</body>

</html>