<?php

	$link = mysql_connect('engr-cpanel-mysql.engr.illinois.edu', 'projectmygym_acc', 'pass123');

	if (!$link) 
	{
	
	die('Could not connect: ' . mysql_error());
	
	}

	mysql_select_db('projectmygym_users');

	$email =$_POST["username"];
	
	$password =$_POST["password"];

	/* if email and password matches the database, delete the account */
		
	$sqldelete="DELETE FROM Users WHERE Email = '$email' AND Pass = '$password'";


	$res=mysql_query($sqldelete);
	
	if($res == FALSE)
		print("Delete Account has failed, wrong password or account name");
	else
		print("Account has been deleted");
		
	mysql_close($link);



?>