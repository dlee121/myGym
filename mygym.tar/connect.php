<?php
mysql_connect('engr-cpanel-mysql.engr.illinois.edu', 'projectmygym_acc', 'pass123');
mysql_select_db('projectmygym_users');
?>