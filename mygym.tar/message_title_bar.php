<div>
<a href='conversation.php' class="msglink">My Conversations</a>
<a class="msglink">&nbsp;&nbsp;|&nbsp&nbsp;</a>
<a href='send.php' class="msglink">Start a New Conversation</a>
</div>